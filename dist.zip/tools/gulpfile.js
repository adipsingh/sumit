'use strict';

var requireDir = require('require-dir');

requireDir('./gulp', {recurse: true});